# Code of Conduct

## Enforcement
- Be professional.
- No sabotage (e.g., fake code).
- Report issues via logs.
- **VIOLATION**: Revert commits.

Inspired by Contributor Covenant.
